# Calculator Using the memento design patter, regular expressions, and language localization
In this coding challenge we are going to create a calculator that uses the memento design patter in order to have an undo function
We also will use language localization. 